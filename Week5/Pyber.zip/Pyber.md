

```python
#Dependencies
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import csv
```


```python
#Reading city data csv
city_csvpath = os.path.join("raw_data","city_data.csv")
city_df=pd.read_csv(city_csvpath)
city_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Reading ride data csv
ride_csvpath = os.path.join("raw_data","ride_data.csv")
ride_df=pd.read_csv(ride_csvpath)
ride_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Average fare per city
Average_fare_per_city = pd.DataFrame(ride_df.groupby('city').mean()['fare'])
Average_fare_per_city.rename(columns = {'fare':'Average fare'}, inplace = True)
Average_fare_per_city.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Average fare</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Total rides per city
Total_rides_per_city = pd.DataFrame(ride_df.groupby('city').count()['fare'])
Total_rides_per_city.rename(columns = {'fare':'Total ride'}, inplace = True)
Total_rides_per_city.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total ride</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>31</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Summary dataframe to plot  
plot_df = city_df.sort_values('city')

#Rename type and driver_count columns
plot_df=plot_df.rename(columns={'type':'City Types', 'driver_count': 'Driver Count'})

#Change city column as index to merge dataframes
plot_df = plot_df.set_index('city')

#Make final dataframe by adding Average fare per city and Total rides per city
plot_df['Average fare'] =Average_fare_per_city['Average fare']
plot_df['Total ride'] =Total_rides_per_city['Total ride']
plot_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Driver Count</th>
      <th>City Types</th>
      <th>Average fare</th>
      <th>Total ride</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>21</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>67</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>16</td>
      <td>Suburban</td>
      <td>37.315556</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>21</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>49</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Create bubble plot using seaborn and matplotlib libraries
sns.lmplot(x='Total ride', y='Average fare', data=plot_df,
           fit_reg=False,hue='City Types',palette=["gold", "lightskyblue", "lightcoral"],
           legend_out=False,scatter_kws={ "s":plot_df['Driver Count']*5,
           "alpha":0.7,"linewidth":0,"edgecolors":'k'}) 

#Set title for the plot
ax = plt.gca()
ax.set_title("Pyber Ride sharing data(2016)")
```




    Text(0.5,1,'Pyber Ride sharing data(2016)')




![png](output_6_1.png)



```python
#% of Total Fares by City Type
Total_fare_per_city = pd.DataFrame(ride_df.groupby('city').sum()['fare'])
Total_fare_per_city.rename(columns = {'fare':'Total fare'}, inplace = True)
Total_fare_per_city.head()

#Add total fare per city column to the plot dataframe
plot_df['Total fare']=Total_fare_per_city['Total fare']

#Calculate Total fare by city type and add to pie plot dataframe
pie_plot1_df=pd.DataFrame(plot_df.groupby('City Types').sum()['Total fare'])

#Create pie plot using matplotlib
pie_plot1_df.plot.pie(y='Total fare',colors=["gold", "lightskyblue", "lightcoral"],autopct='%.2f%%',explode =[0,0,0.1])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x118adc048>




![png](output_7_1.png)



```python
#% of Total Rides by City Type
#Calculate Total ride by city type and add to pie plot dataframe
pie_plot2_df=pd.DataFrame(plot_df.groupby('City Types').sum()['Total ride']) 

#Create pie plot using matplotlib
pie_plot2_df.plot.pie(y='Total ride',colors=["gold", "lightskyblue", "lightcoral"],autopct='%.2f%%',startangle=90)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x117727208>




![png](output_8_1.png)



```python
#% of Total Drivers by City Type
#Calculate driver count by city type and add to pie plot dataframe
pie_plot3_df=pd.DataFrame(plot_df.groupby('City Types').sum()['Driver Count'])


pie_plot3_df.plot.pie(y='Driver Count',colors=["gold", "lightskyblue", "lightcoral"],autopct='%.2f%%',shadow=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x117817400>




![png](output_9_1.png)

